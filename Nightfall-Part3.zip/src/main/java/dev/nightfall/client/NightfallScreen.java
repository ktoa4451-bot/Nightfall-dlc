package dev.nightfall.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class NightfallScreen extends Screen {
    private static final int BG = 0xF20C0D14;
    private static final int PANEL = 0xFF171923;
    private static final int PANEL_HOVER = 0xFF25283A;
    private static final int ACCENT = 0xFF9B6DFF;
    private static final int TEXT = 0xFFF4F2FF;
    private static final int MUTED = 0xFF9A9DB0;

    private final String[] categories = {"Combat", "Visual", "Movement", "Games", "Misc"};
    private int selectedCategory = 3;
    private final List<ModuleEntry> combat = new ArrayList<>();
    private final List<ModuleEntry> visual = new ArrayList<>();
    private final List<ModuleEntry> movement = new ArrayList<>();
    private final List<ModuleEntry> games = new ArrayList<>();
    private final List<ModuleEntry> misc = new ArrayList<>();

    private String selectedGame = "";
    private final Random random = new Random();

    // Snake state
    private final List<int[]> snake = new ArrayList<>();
    private int foodX, foodY, snakeDirX = 1, snakeDirY = 0;
    private int snakeScore = 0;
    private boolean snakeOver = false;
    private long lastSnakeStep = 0L;

    // Space Dodger state
    private double shipX = 0.5;
    private final List<double[]> obstacles = new ArrayList<>();
    private int dodgerScore = 0;
    private boolean dodgerOver = false;
    private long lastObstacle = 0L;
    private long lastFrame = 0L;

    public NightfallScreen() {
        super(Component.literal("Nightfall ClickGUI"));
        combat.add(new ModuleEntry("Aim Assist", "UI placeholder"));
        combat.add(new ModuleEntry("Trigger Bot", "UI placeholder"));
        combat.add(new ModuleEntry("CPS Display", "Click-rate display planned"));
        visual.add(new ModuleEntry("Entity Highlights", "Visual module placeholder"));
        visual.add(new ModuleEntry("Tracers", "Visual module placeholder"));
        visual.add(new ModuleEntry("Name Tags", "Visual module placeholder"));
        movement.add(new ModuleEntry("Fly", "Creative-style flight for test worlds"));
        movement.add(new ModuleEntry("Speed", "Movement multiplier setting"));
        movement.add(new ModuleEntry("Sprint", "Keep sprint enabled"));
        games.add(new ModuleEntry("Snake", "Classic arcade game"));
        games.add(new ModuleEntry("Space Dodger", "Dodge falling obstacles"));
        misc.add(new ModuleEntry("Coordinates", "HUD feature planned"));
        misc.add(new ModuleEntry("Notifications", "Client notifications"));
        misc.add(new ModuleEntry("Config Manager", "Local settings"));
        resetSnake();
    }

    private List<ModuleEntry> activeModules() {
        return switch (selectedCategory) {
            case 0 -> combat;
            case 1 -> visual;
            case 2 -> movement;
            case 3 -> games;
            default -> misc;
        };
    }

    private void resetSnake() {
        snake.clear();
        snake.add(new int[]{5, 8});
        snake.add(new int[]{4, 8});
        snake.add(new int[]{3, 8});
        snakeDirX = 1; snakeDirY = 0;
        snakeScore = 0; snakeOver = false;
        placeFood();
        lastSnakeStep = System.currentTimeMillis();
    }

    private void placeFood() {
        foodX = random.nextInt(18);
        foodY = random.nextInt(12);
        for (int[] part : snake) {
            if (part[0] == foodX && part[1] == foodY) {
                placeFood();
                return;
            }
        }
    }

    private void stepSnake() {
        if (snakeOver) return;
        int[] head = snake.get(0);
        int nx = head[0] + snakeDirX, ny = head[1] + snakeDirY;
        if (nx < 0 || nx >= 18 || ny < 0 || ny >= 12) {
            snakeOver = true; return;
        }
        for (int i = 0; i < snake.size() - 1; i++) {
            int[] p = snake.get(i);
            if (p[0] == nx && p[1] == ny) { snakeOver = true; return; }
        }
        snake.add(0, new int[]{nx, ny});
        if (nx == foodX && ny == foodY) {
            snakeScore += 10;
            placeFood();
        } else {
            snake.remove(snake.size() - 1);
        }
    }

    private void updateDodger() {
        long now = System.currentTimeMillis();
        double dt = Math.min(0.05, (now - lastFrame) / 1000.0);
        lastFrame = now;
        if (!selectedGame.equals("Space Dodger") || dodgerOver) return;

        for (int i = obstacles.size() - 1; i >= 0; i--) {
            double[] o = obstacles.get(i);
            o[1] += dt * (0.22 + Math.min(0.4, dodgerScore / 500.0));
            if (o[1] > 1.05) {
                obstacles.remove(i);
                dodgerScore += 5;
            } else if (o[1] > 0.82 && Math.abs(o[0] - shipX) < 0.075) {
                dodgerOver = true;
            }
        }
        if (now - lastObstacle > Math.max(260, 850 - dodgerScore)) {
            obstacles.add(new double[]{0.08 + random.nextDouble() * 0.84, -0.05});
            lastObstacle = now;
        }
    }

    private void resetDodger() {
        shipX = 0.5;
        obstacles.clear();
        dodgerScore = 0;
        dodgerOver = false;
        lastObstacle = System.currentTimeMillis();
        lastFrame = System.currentTimeMillis();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        if (selectedGame.equals("Snake")) {
            renderSnake(g);
            return;
        }
        if (selectedGame.equals("Space Dodger")) {
            updateDodger();
            renderDodger(g);
            return;
        }

        g.fill(0, 0, width, height, 0x99000000);
        int panelW = Math.min(580, width - 24);
        int panelH = Math.min(360, height - 24);
        int x = (width - panelW) / 2, y = (height - panelH) / 2;
        g.fill(x, y, x + panelW, y + panelH, BG);
        g.fill(x, y, x + panelW, y + 42, PANEL);
        g.fill(x, y, x + 4, y + 42, ACCENT);
        g.drawString(font, "NIGHTFALL", x + 18, y + 9, TEXT);
        g.drawString(font, "CLIENT  /  1.2.0", x + 18, y + 25, MUTED);
        g.drawString(font, "RIGHT SHIFT  •  CLOSE", x + panelW - 154, y + 16, MUTED);

        int sideX = x + 12, sideY = y + 54;
        for (int i = 0; i < categories.length; i++) {
            int cy = sideY + i * 34;
            boolean active = i == selectedCategory;
            g.fill(sideX, cy, sideX + 112, cy + 28, active ? 0xFF302747 : PANEL);
            if (active) g.fill(sideX, cy, sideX + 3, cy + 28, ACCENT);
            g.drawString(font, categories[i], sideX + 12, cy + 10, active ? TEXT : MUTED);
        }

        int contentX = x + 138, contentW = panelW - 150;
        g.drawString(font, categories[selectedCategory].toUpperCase(), contentX, sideY, ACCENT);
        g.drawString(font, selectedCategory == 3 ? "Choose a mini-game to launch." :
                "Click rows to inspect module placeholders.", contentX, sideY + 14, MUTED);

        List<ModuleEntry> modules = activeModules();
        for (int i = 0; i < modules.size(); i++) {
            ModuleEntry module = modules.get(i);
            int ry = sideY + 38 + i * 47;
            boolean hover = mouseX >= contentX && mouseX <= contentX + contentW
                    && mouseY >= ry && mouseY <= ry + 39;
            g.fill(contentX, ry, contentX + contentW, ry + 39, hover ? PANEL_HOVER : PANEL);
            g.drawString(font, module.name(), contentX + 10, ry + 7, TEXT);
            g.drawString(font, module.description(), contentX + 10, ry + 22, MUTED);
            if (selectedCategory == 3) {
                g.fill(contentX + contentW - 66, ry + 9, contentX + contentW - 9, ry + 30, 0xFF302747);
                g.drawCenteredString(font, "PLAY", contentX + contentW - 37, ry + 16, ACCENT);
            } else {
                g.fill(contentX + contentW - 42, ry + 11, contentX + contentW - 8, ry + 27,
                        module.enabled() ? ACCENT : 0xFF383B49);
                g.drawCenteredString(font, module.enabled() ? "ON" : "OFF",
                        contentX + contentW - 25, ry + 15, TEXT);
            }
        }
        g.drawString(font, "Part 3 • Mini Games", x + 14, y + panelH - 17, MUTED);
        super.render(g, mouseX, mouseY, delta);
    }

    private void renderSnake(GuiGraphics g) {
        g.fill(0, 0, width, height, 0xFF090B12);
        int boardW = Math.min(width - 32, 540);
        int cell = Math.max(12, Math.min(24, boardW / 18));
        boardW = cell * 18;
        int boardH = cell * 12;
        int x = (width - boardW) / 2, y = (height - boardH) / 2;
        long now = System.currentTimeMillis();
        if (now - lastSnakeStep > 145) {
            stepSnake();
            lastSnakeStep = now;
        }
        g.fill(x - 8, y - 36, x + boardW + 8, y + boardH + 8, BG);
        g.drawString(font, "NIGHTFALL / SNAKE", x, y - 26, ACCENT);
        g.drawString(font, "SCORE " + snakeScore + "   •   WASD / ARROWS   •   ESC TO EXIT",
                x + 155, y - 26, MUTED);
        g.fill(x, y, x + boardW, y + boardH, 0xFF10131D);
        for (int gx = 0; gx <= 18; gx++) g.fill(x + gx * cell, y, x + gx * cell + 1, y + boardH, 0xFF202434);
        for (int gy = 0; gy <= 12; gy++) g.fill(x, y + gy * cell, x + boardW, y + gy * cell + 1, 0xFF202434);
        g.fill(x + foodX * cell + 3, y + foodY * cell + 3, x + (foodX + 1) * cell - 3,
                y + (foodY + 1) * cell - 3, 0xFFFF6B9D);
        for (int i = 0; i < snake.size(); i++) {
            int[] p = snake.get(i);
            int inset = i == 0 ? 2 : 3;
            g.fill(x + p[0] * cell + inset, y + p[1] * cell + inset,
                    x + (p[0] + 1) * cell - inset, y + (p[1] + 1) * cell - inset,
                    i == 0 ? ACCENT : 0xFF62E6B5);
        }
        if (snakeOver) {
            g.fill(x + 30, y + boardH / 2 - 22, x + boardW - 30, y + boardH / 2 + 28, 0xEE090B12);
            g.drawCenteredString(font, "GAME OVER", x + boardW / 2, y + boardH / 2 - 12, TEXT);
            g.drawCenteredString(font, "Press ENTER to restart  •  ESC to return", x + boardW / 2,
                    y + boardH / 2 + 5, MUTED);
        }
    }

    private void renderDodger(GuiGraphics g) {
        g.fill(0, 0, width, height, 0xFF090B12);
        int boardW = Math.min(width - 32, 540), boardH = Math.min(height - 60, 360);
        int x = (width - boardW) / 2, y = (height - boardH) / 2;
        g.fill(x - 8, y - 30, x + boardW + 8, y + boardH + 8, BG);
        g.drawString(font, "NIGHTFALL / SPACE DODGER", x, y - 20, ACCENT);
        g.drawString(font, "SCORE " + dodgerScore + "   •   A/D OR ARROWS", x + 240, y - 20, MUTED);
        g.fill(x, y, x + boardW, y + boardH, 0xFF10131D);
        for (int i = 0; i < 35; i++) {
            int sx = x + (i * 73 % Math.max(1, boardW));
            int sy = y + (i * 47 % Math.max(1, boardH));
            g.fill(sx, sy, sx + 2, sy + 2, 0xFF4A4568);
        }
        for (double[] o : obstacles) {
            int ox = x + (int) (o[0] * boardW), oy = y + (int) (o[1] * boardH);
            g.fill(ox - 7, oy - 7, ox + 7, oy + 7, 0xFFFF6B9D);
        }
        int px = x + (int) (shipX * boardW), py = y + boardH - 28;
        g.fill(px - 9, py - 10, px + 9, py + 10, ACCENT);
        g.fill(px - 3, py - 16, px + 3, py - 10, TEXT);
        if (dodgerOver) {
            g.fill(x + 30, y + boardH / 2 - 22, x + boardW - 30, y + boardH / 2 + 28, 0xEE090B12);
            g.drawCenteredString(font, "GAME OVER", x + boardW / 2, y + boardH / 2 - 12, TEXT);
            g.drawCenteredString(font, "Press ENTER to restart  •  ESC to return",
                    x + boardW / 2, y + boardH / 2 + 5, MUTED);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!selectedGame.isEmpty()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                selectedGame = "";
                return true;
            }
            if (selectedGame.equals("Snake")) {
                if (keyCode == GLFW.GLFW_KEY_ENTER && snakeOver) { resetSnake(); return true; }
                if ((keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_W) && snakeDirY != 1) {
                    snakeDirX = 0; snakeDirY = -1; return true;
                }
                if ((keyCode == GLFW.GLFW_KEY_DOWN || keyCode == GLFW.GLFW_KEY_S) && snakeDirY != -1) {
                    snakeDirX = 0; snakeDirY = 1; return true;
                }
                if ((keyCode == GLFW.GLFW_KEY_LEFT || keyCode == GLFW.GLFW_KEY_A) && snakeDirX != 1) {
                    snakeDirX = -1; snakeDirY = 0; return true;
                }
                if ((keyCode == GLFW.GLFW_KEY_RIGHT || keyCode == GLFW.GLFW_KEY_D) && snakeDirX != -1) {
                    snakeDirX = 1; snakeDirY = 0; return true;
                }
            } else {
                if (keyCode == GLFW.GLFW_KEY_ENTER && dodgerOver) { resetDodger(); return true; }
                if (keyCode == GLFW.GLFW_KEY_LEFT || keyCode == GLFW.GLFW_KEY_A) {
                    shipX = Math.max(0.05, shipX - 0.07); return true;
                }
                if (keyCode == GLFW.GLFW_KEY_RIGHT || keyCode == GLFW.GLFW_KEY_D) {
                    shipX = Math.min(0.95, shipX + 0.07); return true;
                }
            }
            return super.keyPressed(keyCode, scanCode, modifiers);
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int panelW = Math.min(580, width - 24), panelH = Math.min(360, height - 24);
        int x = (width - panelW) / 2, y = (height - panelH) / 2;
        int sideX = x + 12, sideY = y + 54;
        for (int i = 0; i < categories.length; i++) {
            int cy = sideY + i * 34;
            if (mouseX >= sideX && mouseX <= sideX + 112 && mouseY >= cy && mouseY <= cy + 28) {
                selectedCategory = i;
                return true;
            }
        }
        int contentX = x + 138, contentW = panelW - 150;
        List<ModuleEntry> modules = activeModules();
        for (int i = 0; i < modules.size(); i++) {
            int ry = sideY + 38 + i * 47;
            if (mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= ry && mouseY <= ry + 39) {
                if (selectedCategory == 3) {
                    selectedGame = modules.get(i).name();
                    if (selectedGame.equals("Snake")) resetSnake();
                    if (selectedGame.equals("Space Dodger")) resetDodger();
                } else {
                    modules.get(i).toggle();
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}

# Nightfall Client — Part 3: Mini Games

Minecraft 1.21.11 · Fabric · Java 21

This is a Part 3 source overlay intended to be merged into the existing Nightfall project.
It adds a Games category, Snake, and a small Space Dodger arcade game.

## Merge
Copy `src/main/java/dev/nightfall/client/` into the same package in your Nightfall repository, replacing `NightfallScreen.java` with this version. Keep the existing `NightfallClient.java`, `NightfallConfig.java`, and `ModuleEntry.java` from Part 2.

## Build
Run the existing **Nightfall Build** GitHub Actions workflow. The artifact is produced only if the workflow completes successfully.

## Controls
- Right Shift: open/close ClickGUI
- Games category: choose Snake or Space Dodger
- Snake: WASD or arrow keys; Enter restarts after game over
- Space Dodger: A/D or Left/Right; Enter restarts after game over

These are local mini-games rendered in the client GUI. The visual style is an original dark/purple theme, not a copy of any specific client's assets.
